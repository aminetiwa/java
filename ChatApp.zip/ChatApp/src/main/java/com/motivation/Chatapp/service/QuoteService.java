package com.motivation.Chatapp.service;

import com.motivation.Chatapp.model.Quote;
import com.motivation.Chatapp.repository.QuoteRepository;

import org.springframework.stereotype.Service;

@Service
public class QuoteService {

	private final QuoteRepository QuoteRepository;

	// Injection par constructeur
	public QuoteService(QuoteRepository QuoteRepository) {
		this.QuoteRepository = QuoteRepository;
	}

	public Quote getRandomQuote() {
		return QuoteRepository.findAll().get((int) (Math.random() * QuoteRepository.count()));
	}
}
