package com.motivation.Chatapp.controller;

import com.motivation.Chatapp.model.Quote;
import com.motivation.Chatapp.service.QuoteService;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/getQuote")
public class QuoteController {

	private final QuoteService QuoteService;

	public QuoteController(QuoteService QuoteService) {
		this.QuoteService = QuoteService;
	}

	@GetMapping
	public String getRandomQuote() {
		Quote Quotes = QuoteService.getRandomQuote();
		return Quotes.getTexte();
	}
}
