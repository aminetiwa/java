package com.motivation.Chatapp.controller;

import com.motivation.Chatapp.model.Message;
import com.motivation.Chatapp.model.Quote;
import com.motivation.Chatapp.service.MessageService;
import com.motivation.Chatapp.service.QuoteService;

import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/chat")
public class MessageController {

    private final MessageService messageService;
    private final QuoteService quoteService;

    public MessageController(MessageService messageService, QuoteService quoteService) {
        this.messageService = messageService;
        this.quoteService = quoteService;
    }

    // ✅ Redirige vers  chat
    @GetMapping
    public String getRandomMessage(Model model) {
        model.addAttribute("messages", messageService.getAllPreviousMessage());
        model.addAttribute("users", messageService.getAllUsers());
        return "chat"; // ✅ Fonctionne avec templates/chat
    }

    @GetMapping("/{user}")
    public String getMessages(@PathVariable String user, Model model) {
        model.addAttribute("messages", messageService.getAllPreviousMessageByUsername(user));
        model.addAttribute("users", messageService.getAllUsers());
        return "chat"; // ✅ Toujours la même page 
    }

    @PostMapping
    public String postMessage(@RequestParam("message") String message, 
                              @RequestParam("username") String username, 
                              Model model) {
        Message m = new Message();
        Quote quote = quoteService.getRandomQuote();
        m.settexte(message);
        m.setnom_utilisateur(username);
        m.setmessage(quote.getTexte());

        // ✅ format date (yyyy)
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd MMMM yyyy à HH:mm");
        m.setUpdated_at(java.time.LocalDateTime.now().format(dtf));

        messageService.saveMessage(m);
        model.addAttribute("messages", messageService.getAllPreviousMessage());
        model.addAttribute("users", messageService.getAllUsers());

        return "chat"; // ✅ Retourne la page 
    }
}
