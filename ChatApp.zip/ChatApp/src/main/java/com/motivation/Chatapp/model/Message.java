package com.motivation.Chatapp.model;

import jakarta.persistence.*;

@Entity
public class Message {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String nom_utilisateur;

    private String texte;

    private String message;

    private String maj;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getnom_utilisateur() {
        return nom_utilisateur;
    }

    public void setnom_utilisateur(String nom_utilisateur) {
        this.nom_utilisateur = nom_utilisateur;
    }

    public String gettexte() {
        return texte;
    }

    public void settexte(String texte) {
        this.texte = texte;
    }

    public String getmessage() {
        return message;
    }

    public void setmessage(String message) {
        this.message = message;
    }

    public String getmaj() {
        return maj;
    }

    public void setUpdated_at(String maj) {
        this.maj = maj;
    }
}
